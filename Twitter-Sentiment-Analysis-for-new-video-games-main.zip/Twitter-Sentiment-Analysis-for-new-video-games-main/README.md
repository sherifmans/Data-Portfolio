# Twitter-Sentiment-Analysis-for-new-video-games
# Context
Sentiment analysis can be used to generate important insights from Tweets, the purpose of this porject is to explore how organizations can benefit from using sentiment analysis methods to determine consumers' satisfaction or dissatisfaction for newly released video games. The data used for this project were extracted from Twitter using hashtags specific to a video game. 
# Methodology & Analysis
The VADER unsupervised method was used to generate the sentiment analysis and the final results are displayed in the table below, in this case Call of Duty had the highest overall sentiment score which means it was the most liked game in this group.

<img width="468" alt="image" src="https://user-images.githubusercontent.com/103283892/162525387-782ec953-24be-48d7-95bf-ceeb6ea9abf5.png">
